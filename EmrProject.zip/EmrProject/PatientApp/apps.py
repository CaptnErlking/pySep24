from django.apps import AppConfig


class PatientappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PatientApp'
